# TODO: Implement scoring
